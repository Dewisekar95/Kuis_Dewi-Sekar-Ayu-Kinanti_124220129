package com.example.kinan_kuis_124220129

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
