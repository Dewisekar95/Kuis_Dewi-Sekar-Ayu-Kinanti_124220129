import 'package:flutter/material.dart';
import 'LoginPage.dart'; // Ubah dari 'LoginPage.dart' menjadi 'login_page.dart'
import 'HomePage.dart'; // Ubah dari 'HomePage.dart' menjadi 'home_page.dart'
import 'DetailAboutPage.dart'; // Ubah dari 'DetailAboutPage.dart' menjadi 'detail_about_page.dart'

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),
      routes: {},
    );
  }
}
