import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter/services.dart';
import 'HomePage.dart';

class DetailOrderPage extends StatefulWidget {
  @override
  _DetailOrderPageState createState() => _DetailOrderPageState();
}

class _DetailOrderPageState extends State<DetailOrderPage> {
  String descriptionText = '';

  @override
  void initState() {
    super.initState();
    _loadDescriptionText();
  }

  Future<void> _loadDescriptionText() async {
    String loadedText = await rootBundle.loadString('assets/description.txt');
    setState(() {
      descriptionText = loadedText;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Order Page'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // Navigasi kembali ke HomePage
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => HomePage(username: 'User')),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/header.png',
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20),
            descriptionText.isNotEmpty
                ? Text(
                    descriptionText,
                    style: TextStyle(fontSize: 16),
                    textAlign: TextAlign.justify,
                  )
                : CircularProgressIndicator(),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HomePage(username: 'User')),
                );
              },
              child: Text('Back to Home'),
            ),
          ],
        ),
      ),
    );
  }
}
